﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Artillery.Data.Models.Enums
{
    public enum GunType
    {
        Howitzer, 
        Mortar, 
        FieldGun, 
        AntiAircraftGun, 
        MountainGun, 
        AntiTankGun
    }
}
